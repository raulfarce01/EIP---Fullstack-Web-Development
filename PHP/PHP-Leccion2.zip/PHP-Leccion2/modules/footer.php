<footer>
        <div class="container">
            <div class="row">
                <div class="col-4"></div>
                <div class="col-4"></div>
                <div class="col-4">Autor: Sí, yo </div>
            </div>
        </div>
    </footer>